lista = []

for n in range(5):
    numeros = int(input('Insira um número:'))
    lista.append(numeros)

print(lista)