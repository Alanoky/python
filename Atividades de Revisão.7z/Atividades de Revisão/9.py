def parinpar(num):
    if num % 2 == 0:
        print(f'{num} é um número par.')
    else:
        print(f'{num} é um número impar.')


parinpar(234)
