salario = float(input('Defina o salário:'))
aumento =  float(input('Definade o percentual do aumento:'))
salariototal = (salario * almento) + salario
print(f'O novo salário é de {salariototal} ')