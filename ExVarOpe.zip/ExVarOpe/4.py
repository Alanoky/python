pi = 3.1415
raio = float(input('Defina o raio:'))
altura = float(input('Defina a altura:'))
volume = pi * (raio * raio) * altura
print(f'O volume da lata é: {volume}')