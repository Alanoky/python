P1 = int(input('Digite a nota 1:'))
P2 = int(input('Digite a Nota 2:'))
P3 = int(input('Digite a nota 3:'))
media = (P1 + P2 + P3) / 3
print(f'A média é: {media}')