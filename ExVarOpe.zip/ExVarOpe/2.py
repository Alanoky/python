a = 4
b = 3
print((a + b)**(1/2))