def área(a, b):
    A = a * b
    print(A)


área(float(input('Insira a largura do terreno: ')),float(input('Insira o comprimento do terreno: ')) )