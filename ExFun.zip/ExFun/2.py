def Linha(txt):
    print('-'* len(txt))
    print(txt)
    print('-'* len(txt))


od = str(input('Insira o texto: '))

Linha(od)