def ficha(nome, gol):
    nome = str(input('Insira o nome do jogador: '))
    gol = int(input('Insira a quantidade de gols: '))
ficha()