def maior(*valores):
    S = max

