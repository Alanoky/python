numero = int(input('Digite um número:'))
print(numero - 1, numero + 1)