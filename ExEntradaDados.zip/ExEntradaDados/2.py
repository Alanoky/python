caracter = (input('Digite o primeiro caracter:'))
caracter2 = (input('Digite o segundo caracter: '))
print(f'O usuário digitou {caracter} e {caracter2}')