numero = int(input('Digite um número:'))
print(f'O quadrado do número é: {numero*numero}')