altura = int(input('Digite a altura: '))
base = int(input('Digite a base:'))

perímetro = altura * 2 + base * 2
área = altura * base

print(f'O perímetro é {perímetro}, a área é {área}')