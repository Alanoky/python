pr = (input('Nome do produto:'), input('Quantidade:'), input('Preço:'))
pr2 = (input('Nome do produto:'), input('Quantidade:'), input('Preço:'))
pr3 = (input('Nome do produto:'), input('Quantidade:'), input('Preço:'))
pr4 = (input('Nome do produto:'), input('Quantidade:'), input('Preço:'))