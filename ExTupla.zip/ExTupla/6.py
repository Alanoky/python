p = (input('Número do pedido'), input('itens:'), input('valor'))
p2 = (input('Número do pedido'), input('itens:'), input('valor'))
p3 = (input('Número do pedido'), input('itens:'), input('valor'))