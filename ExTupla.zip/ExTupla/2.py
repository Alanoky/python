n = (4,5,8,9,2,3,1,0)
print(sorted(n))