ev = (input('Nome do Evento:'), input('Data:'), input('Local:'), input('Participantes:'))
ev2 = (input('Nome do Evento:'), input('Data:'), input('Local:'), input('Participantes:'))
ev3 = (input('Nome do Evento:'), input('Data:'), input('Local:'), input('Participantes:'))

