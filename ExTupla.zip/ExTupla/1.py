nome = ('Pajé', 'Lário', 'Juno', 'Bert', 'Ramone' )
idade = (2000000, 16, 16, 16, 55)
print(f'O nome de cada um é: {nome}.\n A idade de cada um é respectivamente: {idade}')