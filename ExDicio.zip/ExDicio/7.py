from random import randint
bib = {'Jogador1': randint(1,6), 'Jogador2': randint(1,6),'Jogador3': randint(1,6),'Jogador4': randint(1,6),}
jogador1 = randint(1,6)
jogador2 = randint(1,6)
jogador3 = randint(1,6)
jogador4 = randint(1,6)

print('O jogador1 tirou', bib['Jogador1'], '\n', 'O jogador2 tirou', bib['Jogador2'],'\n', 'O jogador3 tirou', bib['Jogador3'],'\n', 'O Jogador4 tirou', bib['Jogador4'])