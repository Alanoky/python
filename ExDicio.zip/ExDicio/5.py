notas = {}
while True:
    materia = str(input('Digite a materia:'))
    notas[materia] = float(input(f'Digite a nota de {materia}:'))
    res =str(input('Deseja continuar (S/N):'))

    if res in "Nn":
        break
print(notas)