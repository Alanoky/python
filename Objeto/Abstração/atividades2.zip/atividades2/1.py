class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade


Johnny = Pessoa('Johnny Jocasto Micaflest', 19 )
Pascalho = Pessoa('Pascalho Pingors Miclos', 32)

print(Johnny.nome)