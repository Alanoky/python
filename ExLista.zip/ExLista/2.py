num = []
while True:
    num.append(int(input('Digite um número:')))
    if len(num) == 5:
        break
print(f'Os números são: {num}')