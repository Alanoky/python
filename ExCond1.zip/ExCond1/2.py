num1 = int(input('Digite o primeiro número:'))
num2 = int(input('Digite o segundo número:'))
if num1 > num2:
    print('O primeiro número é maior!')
else:
    print('O segundo número é maior!')
