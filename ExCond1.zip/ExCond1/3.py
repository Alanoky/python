num = int(input('Digite um número:'))
if num %2 == 0:
    print('Par')
else:
    print('Impar')