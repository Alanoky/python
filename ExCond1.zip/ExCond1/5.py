num = int(input('Digite o primeiro número:'))
num2 = int(input('Digite o segundo número:'))
if num == num2:
    print('São iguais!')
else:
    print('São diferentes!')