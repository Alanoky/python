num = int(input('Insira um número:'))
if num < 0:
    print(f'{num} É um número negativo')
elif num == 0:
    print('O número é zero.')
else:
    print(f'{num} é um número positivo')
