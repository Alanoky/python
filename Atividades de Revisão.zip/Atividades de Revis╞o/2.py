base = float(input('Insira a largura do retângulo:'))
altura = float(input('Insira a largura do retângulo: '))

area = base * altura

print(f'A área do retângulo é {area}')