nome = str(input('Insira seu nome:'))
idade = int(input('Insira sua idade:'))

print(f'Seu nome é {nome} e você tem {idade} anos de idade.')