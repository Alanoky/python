for n in range(10):
    n+=1
    par = n % 2 == 0
    print(par)