j = 0
for n in range (1, 101):
    if n%2==0:
        j += 1
print(f'??? {j}')
